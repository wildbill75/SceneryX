====================================================================
                        SCENERYX v1.0.1-BETA
               Flight Simulator Scenery Management Suite
====================================================================

THANK YOU FOR TESTING SCENERYX BETA v1.0.1!

INSTALLATION:
-------------
1. Extract the 'SceneryX' folder anywhere on your PC (e.g. C:\Tools\SceneryX or D:\SceneryX).
2. Double-click 'SceneryX.exe' to launch the application.
3. No installation or setup program required - SceneryX is 100% portable!

FEATURES:
---------
- Automatic detection of MSFS 2020 and MSFS 2024 Community & OneStore sceneries.
- Interactive World Map with 19,450+ airports categorized by Payware, Freeware, Asobo, and Default MSFS.
- Flight Corridor Visualizer (NOPAC Pacific, Silk Road & NAT Tracks): Alt+Click any second airport to draw real-world commercial long-haul flight corridors and filter all custom sceneries en-route! Click anywhere on the map background to clear the corridor.
- Interactive GeoJSON Country Polygon Overlays (Hover highlight & 1-click Country Filter).
- Fixed Viewport Geographic Region Pills (Western Europe, Eastern Europe, North America, Central America & Caribbean, South America, Asia, Middle East, North Africa, Sub-Saharan Africa, Oceania, Pacific Ocean).
- Smart Unified Country/Airport Search.
- Manual 1-click Payware/Freeware pricing category overrides for custom sceneries.
- Persistent 1-time disclaimer terms acceptance saved to user settings.
- Instant 1-click scenery activation and deactivation.
- Advanced BGL-level toggling for multi-airport scenery packs (e.g. France VFR).
- GSX Pro profile discovery and 1-click Drag & Drop installation.
- Operating Airline route maps and flight network visualization.
- Instant CSV & JSON collection exports saved automatically to the 'exports' folder.

DEVELOPER & FEEDBACK:
---------------------
Developed by Bertrand / wildbill75.
Flightsim.to Release: Beta v1.0.1
