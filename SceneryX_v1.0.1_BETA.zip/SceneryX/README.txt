====================================================================
                        SCENERYX v1.0.1-BETA
               Flight Simulator Scenery Management Suite
====================================================================

THANK YOU FOR TESTING SCENERYX BETA v1.0.1!

INSTALLATION:
-------------
1. Extract the 'SceneryX' folder anywhere on your PC (e.g. C:\Tools\SceneryX or D:\SceneryX).
2. Double-click 'SceneryX.exe' to launch the application.
3. No installation or setup program required - SceneryX is 100% portable!

FEATURES:
---------
- Automatic detection of MSFS 2020 and MSFS 2024 Community & OneStore sceneries.
- Interactive World Map with 19,450+ airports categorized by Payware, Freeware, Asobo, and Default MSFS.
- Decoupled Flight Corridor Visualizer: Alt+Click any second airport to display a smooth, unbroken flight arc while accurately discovering all en-route custom sceneries along real-world commercial flight paths (NOPAC Alaska/Japan, NAT Tracks, Silk Road)! Click anywhere on the map background to clear the corridor.
- Interactive GeoJSON Country Polygon Overlays (Hover highlight & 1-click Country Filter).
- Unified Country & Airport Search: Type any English country name (e.g. Spain, Portugal, France, Germany, Italy, Japan, USA, Canada, Brazil) to filter airports by ISO country code, highlight the country polygon, and zoom to country bounds on Enter!
- Dynamic Right Drawer Panel with Dual Modes:
  1. Airport Mode: Displays elevation, coordinates, developer/vendor badges, custom scenery sources, BGL toggles, GSX profile status, airline routes, price management, and user ratings.
  2. Country Mode: Displays country hero flag/ISO badge, total airport metrics, total payware investment spent in country, pricing breakdown (Payware, Freeware, Asobo, Default), airport type counts (International, Regional, General Aviation, Heli/Water), and an interactive list of all custom sceneries in the country!
- Fixed Viewport Geographic Region Pills.
- Smart Unified Country/Airport Search.
- Manual 1-click Payware/Freeware pricing category overrides for custom sceneries.
- Persistent 1-time disclaimer terms acceptance saved to user settings.
- Instant 1-click scenery activation and deactivation.
- Advanced BGL-level toggling for multi-airport scenery packs (e.g. France VFR).
- GSX Profile discovery and 1-click Drag & Drop installation.
- Operating Airline route maps and flight network visualization.
- Instant CSV & JSON collection exports saved automatically to the 'exports' folder.

DEVELOPER & FEEDBACK:
---------------------
Developed by Bertrand / wildbill75.
Flightsim.to Release: Beta v1.0.1
