====================================================================
                        SCENERYX v1.0.1-BETA
               Flight Simulator Scenery Management Suite
====================================================================

THANK YOU FOR TESTING SCENERYX BETA v1.0.1!

INSTALLATION:
-------------
1. Extract the 'SceneryX' folder anywhere on your PC (e.g. C:\Tools\SceneryX or D:\SceneryX).
2. Double-click 'SceneryX.exe' to launch the application.
3. No installation or setup program required - SceneryX is 100% portable!

FEATURES:
---------
- Automatic detection of MSFS 2020 and MSFS 2024 Community & OneStore sceneries.
- Interactive World Map with 19,450+ airports categorized by Payware, Freeware, Asobo, and Default MSFS.
- Advanced Scenery Scanner: Robust discovery of standalone airports, airport light fixes, runway enhancements, night lighting mods, and bespoke patches.
- Antimeridian normalization: Russia and trans-meridian territories are seamlessly rendered on a single continuous map view.
- Operating Airlines: 3-column interactive grid sorted by flight frequency, high-res logos, and rock-solid persistent route lines isolated on a dedicated z-index 550 pane.
- Decoupled Flight Corridor Visualizer: Alt+Click any second airport to display a smooth, unbroken flight arc while accurately discovering all en-route custom sceneries along real-world commercial flight paths.
- Interactive GeoJSON Country Polygon Overlays (Hover highlight & 1-click Country Filter).
- Dynamic Right Drawer Panel with Dual Modes & Strict State Machine:
  1. Airport Mode: Displays elevation, coordinates, developer/vendor badges, custom scenery sources, BGL toggles, GSX profile status, airline routes, price management, and user ratings. 1-Click scenery option selection between Payware/Freeware/Asobo Addons and Default MSFS Base Airport with 100% synchronized button state, developer title, active badge, and map marker updates.
  2. Country Mode: Excludes Default MSFS procedural base airports by default on entry for lightweight performance. Displays full-card country flag watermark with subtle opacity and rectangular flag badge. Exiting Country Mode (via close button, clicking country polygon again, or clicking neutral map area) completely clears country filter, restores left sidebar panel, re-renders global airport markers based on left sidebar filters, and smoothly flies camera zoom to the corresponding Geographic Region! Full vertical expansion for custom sceneries list down to the screen edge.
  3. Strict State Isolation: Switching between Airport Mode, Country Mode, and Map Mode cleanly resets all previous conflicting states, airline routes, flight corridors, and polygon overlays.
- Fixed Viewport Geographic Region Pills.
- Smart Unified Country/Airport Search.
- Manual 1-click Payware/Freeware pricing category overrides for custom sceneries.
- Persistent 1-time disclaimer terms acceptance saved to user settings.
- Instant 1-click scenery activation and deactivation.
- Advanced BGL-level toggling for multi-airport scenery packs (e.g. France VFR).
- GSX Profile discovery and 1-click Drag & Drop installation.
- Operating Airline route maps and flight network visualization.
- Instant CSV & JSON collection exports saved automatically to the 'exports' folder.

DEVELOPER & FEEDBACK:
---------------------
Developed by Bertrand / wildbill75.
Flightsim.to Release: Beta v1.0.1
