====================================================================
                        SCENERYX v1.0.1-BETA
               Flight Simulator Scenery Management Suite
====================================================================

THANK YOU FOR TESTING SCENERYX BETA v1.0.1!

INSTALLATION:
-------------
1. Extract the 'SceneryX' folder anywhere on your PC (e.g. C:\Tools\SceneryX or D:\SceneryX).
2. Double-click 'SceneryX.exe' to launch the application.
3. No installation or setup program required - SceneryX is 100% portable!

FEATURES:
---------
- Automatic detection of MSFS 2020 and MSFS 2024 Community & OneStore sceneries.
- Interactive World Map with 19,450+ airports categorized by Payware, Freeware, Asobo, and Default MSFS.
- Decoupled Flight Corridor Visualizer: Alt+Click any second airport to display a smooth, unbroken flight arc while accurately discovering all en-route custom sceneries along real-world commercial flight paths.
- Interactive GeoJSON Country Polygon Overlays (Hover highlight & 1-click Country Filter).
- Dynamic Right Drawer Panel with Dual Modes & Strict State Machine:
  1. Airport Mode: Displays elevation, coordinates, developer/vendor badges, custom scenery sources, BGL toggles, GSX profile status, airline routes, price management, and user ratings. 1-Click scenery option selection between Payware/Freeware/Asobo Addons and Default MSFS Base Airport with instant button state updates.
  2. Country Mode: Smooth left sidebar auto-slide, full English country name, stylish square flag emoji badge with opacity gradient backdrop, interactive 2-way toggle buttons for Scenery Pricing Breakdown & Airport Types filtering both country scenery list and map markers!
- Fixed Viewport Geographic Region Pills.
- Smart Unified Country/Airport Search.
- Manual 1-click Payware/Freeware pricing category overrides for custom sceneries.
- Persistent 1-time disclaimer terms acceptance saved to user settings.
- Instant 1-click scenery activation and deactivation.
- Advanced BGL-level toggling for multi-airport scenery packs (e.g. France VFR).
- GSX Profile discovery and 1-click Drag & Drop installation.
- Operating Airline route maps and flight network visualization.
- Instant CSV & JSON collection exports saved automatically to the 'exports' folder.

DEVELOPER & FEEDBACK:
---------------------
Developed by Bertrand / wildbill75.
Flightsim.to Release: Beta v1.0.1
